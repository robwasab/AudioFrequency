from unicurses import *

stdscr = initscr()
clear()
noecho()
cbreak()
curs_set(0)
refresh()
