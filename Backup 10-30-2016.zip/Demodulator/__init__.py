import os

os.system('python Demodulator/setup.py build_ext -b ./Demodulator')
